using AutoMapper;

namespace API_Base.Mapping
{
    public class MappingProfile : Profile
    {
        
    }
}